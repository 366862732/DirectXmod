// ===========================================================================
// StormBreak — 最终调色 pass（HDR 合成 + 色彩对比 + 暗角）
//
// 输入：t0 = fx:0（天空 pass 输出：含云层、光缝、丁达尔光束、云影光斑）
//       t1 = fx:1（光追太阳可见性：1 = 受光，0 = 被遮挡）
//       t2 = scene_depth（reverse-Z）
// 输出：scene_color（主渲染目标）
//
// 调色策略：
//   - 线性化后做 HDR 色调映射（Filmic + 冷暗/暖亮对比）
//   - 阴影区偏冷蓝、高光区偏暖金（电影级色彩分离）
//   - 暗部抬升防止死黑 + 暗角增强电影感
//   - 光追阴影 PCF 软边缘（近锐远柔）
// ===========================================================================

Texture2D<float4> InColor : register(t0);
SamplerState InSampler : register(s0);
Texture2D<float4> ShadowTex : register(t1);
SamplerState ShadowSampler : register(s1);
Texture2D<float> SceneDepth : register(t2);
SamplerState SceneDepthSampler : register(s2);

// 设置项顺序与 sky.hlsl 一致（声明顺序 = uniform 顺序）
// [Options[0]]
#define O_BRIGHTNESS    (Options[0].x)
#define O_SATURATION    (Options[0].y)
#define O_CONTRAST      (Options[0].z)
#define O_VIGNETTE      (Options[0].w)
// [Options[1]]
#define O_CLOUD_COVER   (Options[1].x)
#define O_CLOUD_SPEED   (Options[1].y)
#define O_LIGHT_BEAM    (Options[1].z)
#define O_BEAM_SPREAD   (Options[1].w)
// [Options[2]]
#define O_SHADOW_STORM  (Options[2].x)
#define O_SUN_INTENSITY (Options[2].y)
#define O_HAZE          (Options[2].z)
#define O_EXPOSURE      (Options[2].w)
// [Options[3]]
#define O_WARMTH        (Options[3].x)
#define O_SHADOW_LIFT   (Options[3].y)
#define O_SHARPEN       (Options[3].z)
#define O_CLOUD_STEPS   (Options[3].w)
// [Options[4]]
#define O_CLOUD_SIZE    (Options[4].x)
#define O_CLOUD_AMOUNT  (Options[4].y)
#define O_CLOUD_RAIN    (Options[4].z)
#define O_CLOUD_HEIGHT  (Options[4].w)

struct VSOut
{
    float4 position : SV_POSITION;
    float2 uv : TEXCOORD0;
};

// ---------------------------------------------------------------------------
// 软阴影 PCF：8 抽环形采样，半径随距离增大（近锐远柔）
// ---------------------------------------------------------------------------
float sunVisibilityPCF(float2 uv, float radiusPx)
{
    static const float2 kOffsets[8] =
    {
        float2( 0.00,  1.00), float2( 0.71,  0.71),
        float2( 1.00,  0.00), float2( 0.71, -0.71),
        float2( 0.00, -1.00), float2(-0.71, -0.71),
        float2(-1.00,  0.00), float2(-0.71,  0.71)
    };

    float ang = frac(sin(dot(uv * Viewport.xy, float2(12.9898, 78.233))) * 43758.5453) * 6.2831853;
    float cs = cos(ang);
    float sn = sin(ang);
    float2 px = Viewport.zw * radiusPx;

    float sum = 0.0;
    for (int i = 0; i < 8; ++i)
    {
        float2 o = kOffsets[i];
        float2 r = float2(o.x * cs - o.y * sn, o.x * sn + o.y * cs) * px;
        sum += saturate(ShadowTex.SampleLevel(ShadowSampler, uv + r, 0.0).r);
    }
    return sum * 0.125;
}

// ---------------------------------------------------------------------------
// 电影级色彩分离：阴影区偏冷蓝，高光区偏暖金
// 在 sRGB 空间做，避免中间调偏移过大
// ---------------------------------------------------------------------------
float3 colorSplit(float3 color, float warmth)
{
    float luma = dot(color, float3(0.2126, 0.7152, 0.0722));

    // 阴影区（luma < 0.25）：加冷蓝
    float shadowMask = 1.0 - smoothstep(0.12, 0.25, luma);
    float3 coldTint = float3(0.88, 0.94, 1.10);

    // 高光区（luma > 0.70）：加暖金
    float highlightMask = smoothstep(0.65, 0.85, luma);
    float3 warmTint = float3(1.08, 1.02, 0.88);

    color = lerp(color, color * coldTint, shadowMask * 0.30 * warmth);
    color = lerp(color, color * warmTint, highlightMask * 0.25 * warmth);

    return color;
}

// ---------------------------------------------------------------------------
// Filmic 色调映射（基于 ACES 风格但保留中间调）
// 输入为线性 HDR，输出为 sRGB 显示值
// ---------------------------------------------------------------------------
float3 filmicTone(float3 x)
{
    // 简化 ACES：先做曝光归一化，再非线性压缩
    x = x / (1.0 + x * 0.85);
    x = x * (1.0 + 0.15 * x);
    x = x / (1.0 + 0.30 * x * x);
    return x;
}

// ---------------------------------------------------------------------------
// 主函数
// ---------------------------------------------------------------------------
float4 main(VSOut input) : SV_TARGET
{
    float2 uv = input.uv;
    float3 color = InColor.SampleLevel(InSampler, uv, 0.0).rgb;

    // 轻度锐化（4 邻域）
    float sharpen = saturate(O_SHARPEN);
    if (sharpen > 0.002)
    {
        float2 px = Viewport.zw;
        float3 blur = 0.25 * (
            InColor.SampleLevel(InSampler, uv + float2(px.x, 0.0), 0.0).rgb +
            InColor.SampleLevel(InSampler, uv - float2(px.x, 0.0), 0.0).rgb +
            InColor.SampleLevel(InSampler, uv + float2(0.0, px.y), 0.0).rgb +
            InColor.SampleLevel(InSampler, uv - float2(0.0, px.y), 0.0).rgb);
        color += (color - blur) * sharpen;
    }

    // 线性化（scene_color 是 sRGB 显示参考）
    float3 lin = pow(max(color, 0.0), 2.2);

    // 读取深度（reverse-Z：值越大越近，0 = 天空/远处）
    float depth = SceneDepth.SampleLevel(SceneDepthSampler, uv, 0.0);

    // 光追太阳阴影 PCF
    float vis = 1.0;
    float shadowStrength = saturate(PassParams.x);
    float sunUp = saturate(SunDirection.y * 6.0);
    if (shadowStrength > 0.001 && sunUp > 0.001)
    {
        if (depth <= 1e-6)
        {
            vis = 1.0; // 天空：不接收地形阴影
        }
        else
        {
            float2 ndc = float2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
            float4 rel4 = mul(InvViewProj, float4(ndc, depth, 1.0));
            float dist = length(rel4.xyz / max(rel4.w, 1e-4));
            float radius = lerp(0.7, 4.5, saturate(dist / 280.0));
            vis = sunVisibilityPCF(uv, radius);
        }

        // 暴风雨阴影：更深、偏冷（比 Sunlit 更暗更冷）
        float3 shade = lerp(float3(0.42, 0.50, 0.68), float3(1.0, 1.0, 1.0), vis);
        float shadeAmt = shadowStrength * sunUp;
        lin *= lerp(float3(1.0, 1.0, 1.0), shade, shadeAmt);
    }

    // 曝光 + 亮度
    lin *= max(O_EXPOSURE, 0.05) * max(O_BRIGHTNESS, 0.05);

    // Filmic 色调映射
    lin = filmicTone(lin);

    // 编码回 sRGB
    color = pow(saturate(lin), 1.0 / 2.2);

    // 饱和度
    float luma = dot(color, float3(0.2126, 0.7152, 0.0722));
    color = lerp(float3(luma, luma, luma), color, max(O_SATURATION, 0.0));

    // 色彩分离（阴影冷蓝 + 高光暖金）
    float warmthAmt = saturate(O_WARMTH);
    if (warmthAmt > 0.001)
    {
        color = colorSplit(color, warmthAmt);
    }

    // 柔和 S 曲线（对比度）
    float3 sCurve = color * color * (3.0 - 2.0 * color);
    color = lerp(color, sCurve, saturate(O_CONTRAST) * 0.55);

    // 暗部抬升（防止死黑）
    color += O_SHADOW_LIFT;

    // 暗角（电影感）
    float2 d = uv - 0.5;
    float vignette = 1.0 - saturate(O_VIGNETTE) * dot(d, d) * 1.8;
    color *= vignette;

    // 抖动，抑制渐变色带
    float dither = (frac(sin(dot(uv * Viewport.xy, float2(12.9898, 78.233))) * 43758.5453) - 0.5)
                 / 255.0;
    color += dither;

    return float4(saturate(color), 1.0);
}
