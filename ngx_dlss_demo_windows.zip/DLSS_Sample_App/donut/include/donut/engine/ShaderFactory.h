//----------------------------------------------------------------------------------
// File:        ShaderFactory.h
// SDK Version: 2.0
// Email:       vrsupport@nvidia.com
// Site:        http://developer.nvidia.com/
//
// Copyright (c) 2016, NVIDIA CORPORATION. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//  * Redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//  * Redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//  * Neither the name of NVIDIA CORPORATION nor the names of its
//    contributors may be used to endorse or promote products derived
//    from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ``AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
// PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
// OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//----------------------------------------------------------------------------------

#pragma once

#include <string>
#include <vector>
#include <unordered_map>
#include <nvrhi/nvrhi.h>
#include <memory>
#include <filesystem>


namespace donut::vfs
{
    class IBlob;
    class IFileSystem;
}

namespace donut::engine
{
    struct ShaderMacro
    {
        std::string name;
        std::string definition;

        ShaderMacro(const std::string& _name, const std::string& _definition)
            : name(_name)
            , definition(_definition)
        { }
    };

    enum struct ShaderLocation
    {
        FRAMEWORK,
        APPLICATION
    };

    class ShaderFactory
    {
    private:
        nvrhi::DeviceHandle m_Device;
        std::unordered_map<std::string, std::shared_ptr<vfs::IBlob>> m_BytecodeCache;
        std::shared_ptr<vfs::IFileSystem> m_fs;
        std::filesystem::path m_frameworkPath;
        std::filesystem::path m_appPath;

    public:
        ShaderFactory(
            nvrhi::DeviceHandle rendererInterface,
            std::shared_ptr<vfs::IFileSystem> fs,
            std::filesystem::path frameworkPath,
            std::filesystem::path appPath);

        void ClearCache();

        nvrhi::ShaderHandle CreateShader(ShaderLocation location, const char* fileName, const char* entryName, const std::vector<ShaderMacro>* pDefines, nvrhi::ShaderType::Enum shaderType);
        nvrhi::ShaderHandle CreateShader(ShaderLocation location, const char* fileName, const char* entryName, const std::vector<ShaderMacro>* pDefines, const nvrhi::ShaderDesc& desc);
        nvrhi::ShaderLibraryHandle CreateShaderLibrary(ShaderLocation location, const char* fileName, const std::vector<ShaderMacro>* pDefines);

        std::shared_ptr<vfs::IBlob> GetBytecode(ShaderLocation location, const char* fileName, const char* entryName);
    };
}